package presentacion;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.ScrollPane;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import logica.Sistema;

public class Modelo implements Runnable{

    private Sistema miSistema;
    private Vista ventanaPrincipal;
    private Thread hiloDibujo;    
    private BufferedImage dobleBuffer;
    private int estado=1;
    private Image imagen;
    private Canvas lienzo;
    private ScrollPane Scroll;
    private ImageIcon dorso= new ImageIcon(this.getClass().getResource("/images/EdificioCompleto.jpg"));
    private ImageIcon marcador= new ImageIcon(this.getClass().getResource("/images/marcador.png"));
    private Image marc;

    public void setDorso(ImageIcon dorso) {
        this.dorso = dorso;
    }
    public Modelo() {
        hiloDibujo = new Thread(this);
        lienzo= getVentanaPrincipal().getLienzo();
        Scroll=ventanaPrincipal.getScrollPane2();
        Scroll.setSize(Toolkit.getDefaultToolkit().getScreenSize());
        ventanaPrincipal.setScrollPane2(Scroll);
        lienzo.setSize(Toolkit.getDefaultToolkit().getScreenSize().width,1785);
        dobleBuffer = new BufferedImage(getVentanaPrincipal().getLienzo().getWidth(), getVentanaPrincipal().getLienzo().getHeight(), BufferedImage.TYPE_INT_ARGB);
    }

    public Sistema getMiSistema() {
        if(miSistema == null){
            miSistema = new Sistema();
        }
        return miSistema;
    }

    public Vista getVentanaPrincipal() {
        if(ventanaPrincipal == null){
            ventanaPrincipal = new Vista(this);
        }
        return ventanaPrincipal;
    }

    
    public void iniciar() {
        getMiSistema().setEstaDibujando(true);
        getVentanaPrincipal().setSize(Toolkit.getDefaultToolkit().getScreenSize());
        getVentanaPrincipal().setVisible(true);
        hiloDibujo.start();
        miSistema.getAsc1().Start();
        miSistema.getAsc2().Start();
    }

    @Override
    public void run() {
       try{
        while(getMiSistema().isEstaDibujando()){
            dibujar();
            //System.out.print(1); 
            Thread.sleep(10);
        }
       }catch(Exception e){
           
       }
    }

    private void dibujar() {
        int x = getMiSistema().getPosX();
        int y = getMiSistema().getPosY();
        
        if(x<getVentanaPrincipal().getWidth()-130)
          //  enviarCoordenadas(x=x+1,10);
      
        imagen = dorso.getImage();
        marc = marcador.getImage();
        
        String mensaje;
        
        Graphics lapiz = lienzo.getGraphics();
        Graphics lapizInvisible= dobleBuffer.getGraphics();
        
    
        lapizInvisible.setColor(Color.gray);
        lapizInvisible.fillRect(0, 0, lienzo.getWidth(), lienzo.getHeight());
        
        lapizInvisible.drawImage(imagen,338,0,670,1740,null);
        lapizInvisible.setColor(Color.white);
        
        mensaje = "X: "+x+", Y: "+y;
        lapizInvisible.drawString(mensaje, 20, 630);
        
        
        
        
        lapizInvisible.drawImage(miSistema.getAsc1().getPuertas(),442 ,miSistema.getAsc1().getPosY()-128,163,128,null);
        lapizInvisible.drawImage(miSistema.getAsc1().getPuertas(),0, 100,225,400,null);
        lapizInvisible.drawImage(miSistema.getAsc1().getPanelbtns(), 230, 150,null);
        lapizInvisible.drawImage(marc, 10, 30, null);
        mensaje = miSistema.getAsc1().getMsgPisoActual();
        lapizInvisible.drawString(mensaje, 130, 60);
        
        lapizInvisible.drawImage(miSistema.getAsc2().getPuertas(),743,miSistema.getAsc2().getPosY()-128,163,128,null);
        lapizInvisible.drawImage(miSistema.getAsc2().getPuertas(),Toolkit.getDefaultToolkit().getScreenSize().width-250,100,225,400,null);
        lapizInvisible.drawImage(miSistema.getAsc2().getPanelbtns(), 1010, 150,null);
        lapizInvisible.drawImage(marc, 1120, 30, null);
        mensaje = miSistema.getAsc2().getMsgPisoActual();
        lapizInvisible.drawString(mensaje, 1240, 60);
        
        
        lapiz.drawImage(dobleBuffer, 0, 0, lienzo);
    }
   
    public void enviarCoordenadas(int x, int y) {
        getMiSistema().setPosX(x);
        getMiSistema().setPosY(y);        
        getMiSistema().ProcesarCoordenadas();
    }

    public void setImagen(Image imagen) {
        this.imagen = imagen;
    }

    public void cerrar() {
        System.exit(0);
    }
   
}
