package logica; 



public class Sistema {
    private boolean estaDibujando;

    private int posX, posY;
    private Ascensor asc1;
    private Ascensor asc2;
    private int ascuso;
    private int pisoDestino;
    
   
    
    public Sistema() {
        estaDibujando = true;
        asc1= new Ascensor();
        asc2= new Ascensor();
        posX = 0;
        posY = 0;
    }
    

    public boolean isEstaDibujando() {
        return estaDibujando;
    }

    public void setEstaDibujando(boolean estaDibujando) {
        this.estaDibujando = estaDibujando;
    }

    public int getPosX() {
        return posX;
    }

    public void setPosX(int posX) {
        this.posX = posX;
    }

    public int getPosY() {
        return posY;
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }

    public Ascensor getAsc1() {
        return asc1;
    }

    public int getAscuso() {
        return ascuso;
    }

    public void setAscuso(int ascuso) {
        this.ascuso = ascuso;
    }
    
    public Ascensor getAsc2() {
        return asc2;
    }

    public void ProcesarPiso(){
        if(this.ascuso==1){
            asc1.setPisoDestinoAux(pisoDestino);
            asc1.EnlistarParadas();
        }
        if(this.ascuso==2 && pisoDestino!=4 && pisoDestino!=5   && pisoDestino!=6 && this.asc2.getPrioridad()==0){
            asc2.setPisoDestinoAux(pisoDestino);
            asc2.EnlistarParadas();
        }
        if(this.ascuso==2 && this.asc2.getPrioridad()==1){
            asc2.setPisoDestinoAux(pisoDestino);
            asc2.EnlistarParadas();
        }
    }    
       
    public void EscucharBotonesAsc(){
        int aux=13;
        for(int j=174;j<338;j=j+30){
            for(int i=287;i>244;i=i-42){
                aux--;
                if(posX>i && posX<i+27 && posY>j && posY<j+18){
                    pisoDestino=aux;
                    ascuso=1;
                    ProcesarPiso();
                }
            }
            
        }
        if(posX>246 && posX<275 && posY>348 && posY<366){
            pisoDestino=0;
            ascuso=1;
            ProcesarPiso();
        }
        if(posX>286 && posX<315 && posY>348 && posY<366){
            if(asc1.getPrioridad()==0)
                asc1.setPrioridad(1);
            else
                asc1.setPrioridad(0);
        } 
            
        int aux1=13;
        for(int j=174;j<338;j=j+30){
            for(int i=1067;i>1023;i=i-42){
                aux1--;
                if(posX>i && posX<i+27 && posY>j && posY<j+18){
                    pisoDestino=aux1;
                    ascuso=2;
                    ProcesarPiso();
                }
            }
        }
        if(posX>1026 && posX<1055 && posY>348 && posY<366){
            pisoDestino=0;
            ascuso=2;
            ProcesarPiso();
        }     
        if(posX>1066 && posX<1095 && posY>348 && posY<366){
            if(asc2.getPrioridad()==0){
                asc2.setPrioridad(1);
            }
            else{
                asc2.setPrioridad(0);
            }
        } 
    }
    
    public void EscucharBotonesEdificio(){
        if(asc1.getPrioridad()==0){
            int aux=0;
            for(int j=1716;j>0;j=j-133){
                if(this.posY<j && this.posY>j-100 && this.posX>605 && this.posX<653 ){
                    this.ascuso=1;
                    this.pisoDestino=aux;
                    this.ProcesarPiso();
                }
                aux++;
            }
        }
        if(asc2.getPrioridad()==0){
            int aux=0;
            for(int j=1716;j>0;j=j-133){
                if(this.posY<j && this.posY>j-100  && this.posX>700 && this.posX<745 ){
                    this.ascuso=2;
                    this.pisoDestino=aux;
                    this.ProcesarPiso();
                }
                aux++;
            }
        }
    }
    public void ProcesarCoordenadas(){
                EscucharBotonesAsc();
                EscucharBotonesEdificio();
    }     
    
}
