package logica;

import java.awt.Image;
import javax.swing.ImageIcon;


public class Ascensor implements Runnable {
    private int pisoActual;
    private String msgPisoActual;
    private int estadoActual=5;
    private int estadoFuturo=5;
    private int posX;
    private int posY;
    private int prioridad=0;
    private int pisoDestino=10;
    private int pisoDestinoAux=0;
    private int posDestinoX=500;
    private int posDestinoY=1730-(130*pisoDestino);
    private ImageIcon puerta,panel;
    private Image puertas,panelbtns;
    private Thread hilo1;
    private int[] paradasasc= new int[100];
    private int indicePasc=0;
    private int indiceProceso=0;
    private int posAuxasc=0;
  

    public Ascensor() {
        this.pisoActual = 5;
        this.estadoActual = 5;
        this.posX = 500;
        this.posY = 500;
        this.puerta = new ImageIcon(this.getClass().getResource("/images/" + estadoActual + ".jpg"));
        this.panel = new ImageIcon(this.getClass().getResource("/images/panel.png"));
        this.puertas= puerta.getImage();
        this.panelbtns= panel.getImage();
        hilo1= new Thread(this,"hilo 1");
        
    }

    public String getMsgPisoActual() {
        return msgPisoActual;
    }
    
    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public int getPisoDestino() {
        return pisoDestino;
    }

    public void setPisoDestino(int pisoDestino) {
        this.pisoDestino = pisoDestino;
    }

   
    public int getPisoActual() {
        return pisoActual;
    }

    public void setPisoActual(int piso) {
        this.pisoActual = piso;
    }

    public int getEstadoActual() {
        return estadoActual;
    }

    public void setEstadoActual(int estado) {
        this.estadoActual = estado;
        setPuerta();
    }

    public int getPosX() {
        return posX;
    }

    public void setPosX(int posX) {
        this.posX = posX;
    }

    public int getPosY() {
        return posY;
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }

    public int getPosDestinoX() {
        return posDestinoX;
    }

    public void setPosDestinoX(int posDestinoX) {
        this.posDestinoX = posDestinoX;
    }

    public int getPosDestinoY() {
        return posDestinoY;
    }

    public void setPosDestinoY(int posDestinoY) {
        this.posDestinoY = posDestinoY;
    }
    
    public int getEstadoFuturo() {
        return estadoFuturo;
    }
    
    public void setEstadoFuturo(int estadoFuturo) {
        this.estadoFuturo = estadoFuturo;
    }

    public int getPisoDestinoAux() {
        return pisoDestinoAux;
    }

    public void setPisoDestinoAux(int pisoDestinoAux) {
        this.pisoDestinoAux = pisoDestinoAux;
    }
    

    public ImageIcon getPanel() {
        return panel;
    }

    public void setPanel(ImageIcon panel) {
        this.panel = panel;
    }

    public Image getPanelbtns() {
        return panelbtns;
    }

    public void setPanelbtns(Image panelbtns) {
        this.panelbtns = panelbtns;
    }
    
    
    public ImageIcon getPuerta() {
        return puerta;
    }

    public void setPuerta() {
        ImageIcon Aux= new ImageIcon(this.getClass().getResource("/images/" + estadoActual + ".jpg"));
        this.puerta = Aux;
        setPuertas(Aux);
    }

    public Image getPuertas() {
        return puertas;
    }

    public void setPuertas(ImageIcon puertas) {
        this.puertas = puertas.getImage();
    }
    
    public void IdentificarPisoActual(){
        int aux=14;
        for(int i=0;i<1730;i=i+133){
           if(posY>i && posY<i+133){
               this.pisoActual=aux;
            } 
           aux--;
        }
        System.out.println(this.pisoActual);
        if(pisoActual==3)
            msgPisoActual="S1";
        if(pisoActual==2)
            msgPisoActual="S2";
        if(pisoActual==1)
            msgPisoActual="S3";
        if(pisoActual==4 || pisoActual==5 || pisoActual==6 || pisoActual==7 || 
                pisoActual==8 || pisoActual==9 ||pisoActual==10 || pisoActual==11 || pisoActual==12 ||pisoActual==13 )
            msgPisoActual=""+(pisoActual-3);
        
    }
    
    public void ActualizarEstado(int estado){
        if(this.estadoActual<estado)    
            setEstadoActual(this.estadoActual+1);
        if(this.estadoActual>estado)    
            setEstadoActual(this.estadoActual-1);
    }
    
    public void AsignacionPiso(){
        //System.out.println(this.indiceProceso);
        posDestinoY=1730-(133*this.pisoDestino);
    }
    
    public void MoverAsc(){
        if(this.posX<this.posDestinoX)
            setPosX(this.posX+1);
        if(this.posX>this.posDestinoX)
            setPosX(this.posX-1);
        if(this.posY<this.posDestinoY)
            setPosY(this.posY+1);
        if(this.posY>this.posDestinoY)
            setPosY(this.posY-1);
    }
    public void EnlistarParadas(){
        if(this.pisoDestinoAux!=this.pisoDestino){
            this.paradasasc[this.indicePasc]=pisoDestinoAux;
            indicePasc++;
        }
    }
    
    public void ProcesarParadas(){
        try{
        this.pisoDestino=this.paradasasc[indiceProceso];
        if(posY == posDestinoY && posY != posAuxasc && estadoActual==1 && indiceProceso+1<indicePasc ){
            //System.out.print(1);
            this.indiceProceso++;
            posAuxasc=posY;
            Thread.sleep(1000);
        }
        }catch(Exception e){
            
        }
    }
        
    
    public void run() {
        try{
            while (true){
                IdentificarPisoActual();
                ProcesarParadas();
                AsignacionPiso();
                if(this.posY!=this.posDestinoY){
                   estadoFuturo=5;
                }
                if(estadoActual!=estadoFuturo ){
                    ActualizarEstado(estadoFuturo);
                    Thread.sleep(150);
                }
                if(estadoActual==5 && this.posY!=this.posDestinoY)
                    MoverAsc();
                if(this.posY==this.posDestinoY){
                   estadoFuturo=1;
                }
                Thread.sleep(5);
                
            }
        }catch(Exception e){
        
        }
    }
    public void Start(){
        hilo1.start();
    }
    
    
}
